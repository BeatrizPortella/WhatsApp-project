# 🔄 MUDANÇA IMPORTANTE: Nova Biblioteca WhatsApp

## ⚠️ Por que mudamos?

O **Baileys** está com problemas de compatibilidade (erro 405). Mudamos para **whatsapp-web.js** que é:
- ✅ Mais estável
- ✅ Melhor mantido
- ✅ Usa Puppeteer (navegador real)
- ✅ Menos chance de banimento

## 🚀 Como usar agora:

### 1️⃣ Pare todos os processos antigos

```bash
# Se estiver rodando com PM2
pm2 stop all
pm2 delete all

# Ou pressione Ctrl+C nos terminais
```

### 2️⃣ Limpe a sessão antiga

```bash
rm -rf auth_info/
```

### 3️⃣ Execute o novo bot

```bash
node src/bot-whatsapp-web.js
```

### 4️⃣ O que vai acontecer:

```
🚀 Iniciando bot WhatsApp...

⏳ Carregando: 10% - Iniciando navegador
⏳ Carregando: 30% - Conectando ao WhatsApp
⏳ Carregando: 50% - Aguardando autenticação

🔐 ESCANEIE O QR CODE ABAIXO COM SEU WHATSAPP:

████████████████████████
████  ██  ██████  ██████
████████████████████████

Abra o WhatsApp > Aparelhos conectados > Conectar aparelho

✅ Autenticado com sucesso!
⏳ Carregando: 80% - Sincronizando mensagens
✅ WhatsApp conectado com sucesso!
📱 Aguardando mensagens...
```

### 5️⃣ Em outro terminal, inicie o servidor:

```bash
node src/server.js
```

### 6️⃣ Acesse a interface:

```
http://localhost:3000
```

## 📝 Diferenças importantes:

### Formato do número mudou:

**Antes (Baileys):**
```
5511999999999@s.whatsapp.net
```

**Agora (whatsapp-web.js):**
```
5511999999999@c.us
```

> Não se preocupe! O sistema detecta automaticamente o formato correto.

## ⚡ Vantagens da nova biblioteca:

1. **Mais estável** - Menos erros de conexão
2. **QR Code sempre funciona** - Não tem erro 405
3. **Melhor sincronização** - Carrega histórico corretamente
4. **Suporte a mídia** - Funciona com imagens, vídeos, áudios
5. **Menos chance de ban** - Usa navegador real (Chromium)

## 🐛 Possíveis avisos (normais):

Você pode ver alguns avisos sobre pacotes deprecated. **Ignore-os**, são normais e não afetam o funcionamento:

```
npm warn deprecated inflight@1.0.6
npm warn deprecated rimraf@2.7.1
```

## 🔧 Solução de problemas:

### Erro: "Chromium not found"

```bash
# Instale o Chromium manualmente
npx puppeteer browsers install chrome
```

### Bot trava em "Carregando"

- **Normal!** Pode levar até 2 minutos na primeira vez
- Aguarde pacientemente
- Não feche o terminal

### QR Code não aparece

```bash
# Limpe tudo e tente novamente
rm -rf auth_info/
rm -rf .wwebjs_auth/
node src/bot-whatsapp-web.js
```

## 📊 Atualizar PM2 (produção):

Edite o `ecosystem.config.js`:

```javascript
{
  name: 'whatsapp-bot',
  script: './src/bot-whatsapp-web.js',  // ← MUDOU AQUI
  // ... resto igual
}
```

Depois:

```bash
pm2 start ecosystem.config.js
pm2 save
```

## ✅ Teste completo:

1. ✅ Bot iniciado
2. ✅ QR Code escaneado
3. ✅ Mensagem "WhatsApp conectado"
4. ✅ Servidor rodando na porta 3000
5. ✅ Interface acessível no navegador
6. ✅ Envie uma mensagem de teste para o número
7. ✅ Mensagem aparece na interface
8. ✅ Responda pela interface
9. ✅ Mensagem chega no WhatsApp com prefixo do atendente

---

**Agora sim! Sistema 100% funcional! 🎉**
