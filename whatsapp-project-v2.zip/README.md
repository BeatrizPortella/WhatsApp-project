# 📱 Sistema de Atendimento WhatsApp Multi-Operador

Sistema completo de atendimento via WhatsApp com suporte para múltiplos operadores usando a biblioteca Baileys (API não oficial).

## ⚠️ Aviso Importante

Este sistema utiliza a API **não oficial** do WhatsApp através da biblioteca Baileys. O uso pode resultar em:
- Banimento temporário ou permanente do número
- Violação dos Termos de Serviço do WhatsApp
- Recomendado apenas para uso pessoal ou com baixo volume de mensagens

## 🎯 Funcionalidades

- ✅ Conexão com WhatsApp Web via Baileys
- ✅ Suporte para 2 ou mais operadores
- ✅ Identificação automática do atendente nas mensagens
- ✅ Interface web moderna e responsiva
- ✅ Histórico completo de conversas
- ✅ Atualização em tempo real
- ✅ Gerenciamento de status das conversas
- ✅ Banco de dados PostgreSQL (Supabase)

## 🛠️ Tecnologias

- **Backend**: Node.js, Express
- **WhatsApp**: Baileys
- **Banco de Dados**: PostgreSQL (Supabase)
- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Gerenciamento de Processos**: PM2

## 📋 Pré-requisitos

- Node.js 18+ instalado
- Conta no Supabase (gratuita)
- Número de WhatsApp (recomendado: número antigo e verificado)
- Servidor Linux (AWS EC2, VPS, etc.) ou computador local

## 🚀 Instalação

### 1. Clone ou baixe o projeto

```bash
cd ~/
git clone <seu-repositorio>
cd WhatsApp-project
```

### 2. Instale as dependências

```bash
npm install
```

### 3. Configure o banco de dados

1. Acesse [Supabase](https://supabase.com) e crie uma conta
2. Crie um novo projeto
3. Vá em **SQL Editor** e execute o script `database/schema.sql`
4. Copie a **Connection String** em Settings > Database

### 4. Configure as variáveis de ambiente

```bash
cp .env.example .env
nano .env
```

Edite o arquivo `.env`:

```env
DATABASE_URL=postgresql://postgres:[SUA-SENHA]@db.[SEU-PROJETO].supabase.co:5432/postgres
PORT=3000
NODE_ENV=production
```

### 5. Primeira execução (gerar QR Code)

```bash
node src/bot.js
```

- Escaneie o QR Code com seu WhatsApp
- Aguarde a mensagem "✅ WhatsApp conectado!"
- Pressione `Ctrl + C` para parar

### 6. Inicie com PM2 (produção)

```bash
npm run pm2:start
```

## 📱 Uso

### Acessar a Interface

Abra o navegador em:
```
http://localhost:3000
```

Ou, se estiver em servidor remoto:
```
http://SEU_IP_PUBLICO:3000
```

### Como Funciona

1. **Cliente envia mensagem** → Aparece na lista de conversas
2. **Operador seleciona a conversa** → Vê todo o histórico
3. **Operador escolhe seu nome** no seletor
4. **Operador digita e envia** → Mensagem vai com prefixo do nome
5. **Cliente recebe**: `*João Silva:* Olá, como posso ajudar?`

## 🔧 Comandos Úteis

```bash
# Iniciar com PM2
npm run pm2:start

# Ver status
pm2 status

# Ver logs em tempo real
npm run pm2:logs

# Reiniciar
npm run pm2:restart

# Parar
npm run pm2:stop

# Remover do PM2
pm2 delete all
```

## 📁 Estrutura do Projeto

```
WhatsApp-project/
├── src/
│   ├── bot.js          # Bot WhatsApp (Baileys)
│   ├── server.js       # Servidor Express
│   └── database.js     # Funções do banco de dados
├── public/
│   ├── index.html      # Interface web
│   ├── styles.css      # Estilos
│   └── script.js       # Lógica frontend
├── database/
│   └── schema.sql      # Script SQL
├── auth_info/          # Sessão WhatsApp (gerado automaticamente)
├── logs/               # Logs do PM2 (gerado automaticamente)
├── .env                # Variáveis de ambiente (você cria)
├── .env.example        # Exemplo de .env
├── .gitignore
├── package.json
├── ecosystem.config.js # Configuração PM2
└── README.md
```

## 🔒 Segurança

### Boas Práticas

- ✅ Nunca commite o arquivo `.env`
- ✅ Nunca commite a pasta `auth_info/`
- ✅ Use firewall para proteger a porta 3000
- ✅ Configure SSL/HTTPS em produção
- ✅ Limite acesso à interface apenas para IPs confiáveis

### Configurar Firewall (AWS EC2)

1. Console AWS → EC2 → Security Groups
2. Editar Inbound Rules
3. Adicionar regra:
   - Type: Custom TCP
   - Port: 3000
   - Source: **My IP** (seu IP fixo)

## 🚨 Evitar Banimento

### O que EVITAR:
- ❌ Envio em massa (>50 msgs/dia para números diferentes)
- ❌ Mensagens idênticas repetidas
- ❌ Respostas instantâneas (< 2 segundos)
- ❌ Usar número novo (< 30 dias)

### O que é SEGURO:
- ✅ Atendimento humanizado
- ✅ Respostas naturais
- ✅ Número antigo e verificado
- ✅ Baixo volume de mensagens

## 🐛 Solução de Problemas

### QR Code não aparece

```bash
# Deletar sessão antiga
rm -rf auth_info/

# Rodar novamente
node src/bot.js
```

### Erro de conexão com banco

- Verifique se a `DATABASE_URL` está correta no `.env`
- Teste a conexão no Supabase Dashboard
- Verifique se executou o `schema.sql`

### WhatsApp desconecta sozinho

- Normal após atualizações do WhatsApp
- Basta escanear o QR Code novamente
- Use número verificado e antigo

### Porta 3000 já em uso

```bash
# Encontrar processo
lsof -i :3000

# Matar processo
kill -9 <PID>

# Ou mudar a porta no .env
PORT=3001
```

## 📊 Próximas Melhorias

- [ ] Autenticação de operadores
- [ ] Notificações push
- [ ] Chatbot com respostas automáticas
- [ ] Relatórios e estatísticas
- [ ] Suporte a mídia (imagens, vídeos)
- [ ] Integração com CRM

## 📄 Licença

MIT

## 🤝 Suporte

Para dúvidas ou problemas, abra uma issue no repositório.

---

**Desenvolvido com ❤️ para facilitar o atendimento via WhatsApp**
