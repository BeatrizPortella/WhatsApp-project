# 🔧 Solução para Erro 405 - Connection Failure

## ✅ O que foi feito:

1. **Limpeza da sessão corrompida**
   ```bash
   rm -rf auth_info/
   ```

2. **Atualização do Baileys**
   ```bash
   npm install @whiskeysockets/baileys@latest
   ```

3. **Melhorias no código:**
   - ✅ Adicionado `fetchLatestBaileysVersion()` para usar versão mais recente
   - ✅ Configurações otimizadas: `markOnlineOnConnect: false`, `syncFullHistory: false`
   - ✅ Timeout aumentado: `defaultQueryTimeoutMs: 60000`
   - ✅ Melhor tratamento de erros com status codes

## 🚀 Agora execute novamente:

```bash
node src/bot.js
```

## 📱 O que deve acontecer:

1. ✅ Mensagem: "🚀 Iniciando bot WhatsApp..."
2. ✅ QR Code aparece no terminal
3. ✅ Você escaneia com o WhatsApp
4. ✅ Mensagem: "✅ WhatsApp conectado com sucesso!"

## ⚠️ Se o erro 405 persistir:

### Possíveis causas:

1. **Número bloqueado pelo WhatsApp**
   - Use um número antigo (> 30 dias)
   - Número deve estar verificado
   - Evite números que já foram banidos antes

2. **Problema de rede/firewall**
   - Desative VPN temporariamente
   - Verifique se não há proxy bloqueando
   - Teste em outra rede (4G do celular)

3. **WhatsApp atualizou protocolo**
   - Aguarde atualização do Baileys
   - Monitore: https://github.com/WhiskeySockets/Baileys/issues

### Solução alternativa:

Se o erro continuar, tente usar outro número de WhatsApp temporariamente para testar.

## 📊 Códigos de erro comuns:

- **401** - Não autorizado (QR Code expirado)
- **403** - Proibido (número banido)
- **405** - Método não permitido (protocolo incompatível ou sessão corrompida)
- **428** - Precondition Required (precisa escanear QR Code)

## 🔍 Debug avançado:

Se precisar ver mais detalhes do erro, altere temporariamente no `src/bot.js`:

```javascript
logger: P({ level: 'debug' })  // Linha 23
```

Isso mostrará logs detalhados da conexão.
