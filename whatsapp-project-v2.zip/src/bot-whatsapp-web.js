require('dotenv').config();
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { salvarMensagemCliente } = require('./database');

let client = null;
let qrCodeData = null;
let isConnected = false;

/**
 * Conecta ao WhatsApp Web usando whatsapp-web.js
 */
async function connectToWhatsApp() {
    console.log('🚀 Iniciando bot WhatsApp...\n');

    // Cria cliente WhatsApp
    client = new Client({
        authStrategy: new LocalAuth({
            dataPath: './auth_info'
        }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ]
        }
    });

    // Evento: QR Code gerado
    client.on('qr', async (qr) => {
        console.log('\n🔐 QR CODE DISPONÍVEL NA INTERFACE WEB!');
        console.log('   Acesse: http://SEU_IP:3000/setup.html\n');

        // Gerar QR Code em base64 para exibir na web
        const QRCode = require('qrcode');
        qrCodeData = await QRCode.toDataURL(qr);
        isConnected = false;
    });

    // Evento: Autenticando
    client.on('authenticated', () => {
        console.log('✅ Autenticado com sucesso!');
    });

    // Evento: Autenticação falhou
    client.on('auth_failure', (msg) => {
        console.error('❌ Falha na autenticação:', msg);
        console.log('💡 Tente deletar a pasta auth_info e escanear novamente\n');
    });

    // Evento: Cliente pronto
    client.on('ready', () => {
        console.log('✅ WhatsApp conectado com sucesso!');
        console.log('📱 Aguardando mensagens...\n');
        isConnected = true;
        qrCodeData = null; // Limpa QR Code após conectar
    });

    // Evento: Desconectado
    client.on('disconnected', (reason) => {
        console.log('❌ WhatsApp desconectado. Motivo:', reason);
        console.log('🔄 Reinicie o bot para reconectar\n');
    });

    // Evento: Mensagem recebida
    client.on('message', async (message) => {
        try {
            // Ignora mensagens de status e grupos
            if (message.from === 'status@broadcast' || message.from.includes('@g.us')) {
                return;
            }

            // Ignora mensagens enviadas por você
            if (message.fromMe) {
                return;
            }

            const from = message.from; // Número do cliente
            let text = '';

            // Detecta tipo de mensagem
            if (message.hasMedia) {
                // Mensagem contém mídia
                const media = await message.downloadMedia();

                if (media) {
                    const mediaType = media.mimetype.split('/')[0]; // image, video, audio, application

                    switch (mediaType) {
                        case 'image':
                            text = message.body ? `📷 Imagem: ${message.body}` : '📷 Imagem';
                            break;
                        case 'video':
                            text = message.body ? `🎥 Vídeo: ${message.body}` : '🎥 Vídeo';
                            break;
                        case 'audio':
                            text = '🎵 Áudio';
                            break;
                        case 'application':
                            text = message.body ? `📄 Documento: ${message.body}` : '📄 Documento';
                            break;
                        default:
                            text = '📎 Arquivo';
                    }

                    console.log(`📩 Nova mídia de ${from}: ${text}`);
                } else {
                    text = '📎 Mídia (não foi possível baixar)';
                }
            } else {
                // Mensagem de texto
                text = message.body || '[Mensagem vazia]';
                console.log(`📩 Nova mensagem de ${from}:`);
                console.log(`   ${text}\n`);
            }

            // Salva mensagem no banco de dados
            await salvarMensagemCliente(from, text);

        } catch (error) {
            console.error('❌ Erro ao processar mensagem:', error);
        }
    });

    // Evento: Carregando (mostra progresso)
    client.on('loading_screen', (percent, message) => {
        console.log(`⏳ Carregando: ${percent}% - ${message}`);
    });

    // Inicializa o cliente
    try {
        await client.initialize();
    } catch (error) {
        console.error('❌ Erro ao inicializar WhatsApp:', error);
        process.exit(1);
    }

    return client;
}

/**
 * Envia mensagem com identificação do atendente
 * @param {string} numero - Número do destinatário (formato: 5511999999999@c.us)
 * @param {string} texto - Texto da mensagem
 * @param {number} atendenteId - ID do atendente
 * @param {string} nomeAtendente - Nome do atendente
 */
async function enviarMensagem(numero, texto, atendenteId, nomeAtendente) {
    try {
        if (!client) {
            throw new Error('WhatsApp não está conectado. Inicie o bot primeiro.');
        }

        // Verifica se o cliente está pronto
        const state = await client.getState();
        if (state !== 'CONNECTED') {
            throw new Error(`WhatsApp não está pronto. Estado atual: ${state}`);
        }

        // Garante que o número está no formato correto (@c.us)
        let numeroFormatado = numero;
        if (!numero.includes('@')) {
            numeroFormatado = `${numero}@c.us`;
        } else if (numero.includes('@s.whatsapp.net')) {
            // Converte formato Baileys para whatsapp-web.js
            numeroFormatado = numero.replace('@s.whatsapp.net', '@c.us');
        }

        // Formata a mensagem com o nome do atendente em negrito em linha separada
        const mensagemCompleta = `*${nomeAtendente}*\n${texto}`;

        // Envia a mensagem
        await client.sendMessage(numeroFormatado, mensagemCompleta);

        console.log(`✅ Mensagem enviada por ${nomeAtendente} para ${numeroFormatado}`);

        return { success: true };

    } catch (error) {
        console.error('❌ Erro ao enviar mensagem:', error.message);
        throw new Error(`Erro ao enviar mensagem: ${error.message}`);
    }
}

/**
 * Obtém o cliente do WhatsApp (para uso em outros módulos)
 */
function getClient() {
    return client;
}

/**
 * Obtém o status da conexão WhatsApp
 */
function getConnectionStatus() {
    return {
        connected: isConnected,
        hasClient: client !== null,
        qr: qrCodeData
    };
}

/**
 * Obtém o QR Code em base64
 */
function getQRCode() {
    return qrCodeData;
}

// Exporta funções
module.exports = {
    connectToWhatsApp,
    enviarMensagem,
    getClient,
    getConnectionStatus,
    getQRCode
};

// Inicia a conexão se este arquivo for executado diretamente
if (require.main === module) {
    connectToWhatsApp();
}
