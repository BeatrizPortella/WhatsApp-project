# 🚀 Deploy na AWS EC2 - Guia Completo

## 📋 Pré-requisitos

- ✅ Conta AWS criada
- ✅ Projeto funcionando localmente
- ✅ Supabase configurado
- ✅ Número WhatsApp para conectar

---

## 1️⃣ CRIAR INSTÂNCIA EC2

### Passo 1: Acessar Console AWS

1. Login em: https://console.aws.amazon.com
2. Região: **São Paulo (sa-east-1)**
3. Buscar: **EC2** → Clicar

### Passo 2: Lançar Instância

1. Clique em **"Launch Instance"**
2. Configure:

**Nome:**
```
whatsapp-atendimento-prod
```

**Sistema Operacional:**
- **Ubuntu Server 22.04 LTS** (Free tier eligible)
- Arquitetura: 64-bit (x86)

**Tipo de Instância:**
- **t2.micro** (1 vCPU, 1 GB RAM) - Free tier

**Par de Chaves:**
1. "Create new key pair"
2. Nome: `whatsapp-aws-key`
3. Tipo: RSA
4. Formato: `.pem`
5. **BAIXE E GUARDE EM LOCAL SEGURO!**

**Configurações de Rede:**
- ✅ Allow SSH traffic from: **My IP**
- ✅ Allow HTTP traffic from the internet
- ✅ Allow HTTPS traffic from the internet

**Armazenamento:**
- 20 GB gp3 (Free tier permite até 30 GB)

3. Clique em **"Launch Instance"**
4. Aguarde 1-2 minutos

### Passo 3: Configurar Regras de Segurança

1. Vá em **Security Groups**
2. Selecione o grupo da instância
3. **Edit inbound rules** → **Add rule**:

```
Type: Custom TCP
Port: 3000
Source: My IP (ou 0.0.0.0/0 para acesso público)
Description: Interface Web
```

4. Salvar

### Passo 4: Anotar IP Público

1. Vá em **Instances**
2. Clique na instância
3. Copie o **Public IPv4 address** (ex: 54.207.123.45)

---

## 2️⃣ CONECTAR AO SERVIDOR

### No seu computador (Mac):

```bash
# Mover chave para pasta segura
mkdir -p ~/.ssh
mv ~/Downloads/whatsapp-aws-key.pem ~/.ssh/

# Dar permissão correta
chmod 400 ~/.ssh/whatsapp-aws-key.pem

# Conectar
ssh -i ~/.ssh/whatsapp-aws-key.pem ubuntu@SEU_IP_PUBLICO
```

Substitua `SEU_IP_PUBLICO` pelo IP copiado.

**Primeira conexão:** Digite `yes` quando perguntar.

---

## 3️⃣ CONFIGURAR SERVIDOR

### Atualizar Sistema

```bash
sudo apt update && sudo apt upgrade -y
```

### Instalar Node.js 20

```bash
# Adicionar repositório
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Instalar
sudo apt install -y nodejs

# Verificar
node -v  # Deve mostrar v20.x.x
npm -v
```

### Instalar PM2

```bash
sudo npm install -g pm2
```

### Instalar Dependências do Chromium

```bash
sudo apt install -y \
  ca-certificates \
  fonts-liberation \
  libappindicator3-1 \
  libasound2 \
  libatk-bridge2.0-0 \
  libatk1.0-0 \
  libc6 \
  libcairo2 \
  libcups2 \
  libdbus-1-3 \
  libexpat1 \
  libfontconfig1 \
  libgbm1 \
  libgcc1 \
  libglib2.0-0 \
  libgtk-3-0 \
  libnspr4 \
  libnss3 \
  libpango-1.0-0 \
  libpangocairo-1.0-0 \
  libstdc++6 \
  libx11-6 \
  libx11-xcb1 \
  libxcb1 \
  libxcomposite1 \
  libxcursor1 \
  libxdamage1 \
  libxext6 \
  libxfixes3 \
  libxi6 \
  libxrandr2 \
  libxrender1 \
  libxss1 \
  libxtst6 \
  lsb-release \
  wget \
  xdg-utils
```

---

## 4️⃣ ENVIAR PROJETO PARA O SERVIDOR

### Opção A: Via Git (Recomendado)

**No seu computador:**

```bash
cd /Users/bestrizportella/Documents/desenvolvimentoWeb/WhatsApp-project

# Inicializar git (se ainda não fez)
git init
git add .
git commit -m "Deploy inicial"

# Criar repositório no GitHub e fazer push
# Depois, no servidor:
```

**No servidor AWS:**

```bash
cd ~
git clone https://github.com/SEU_USUARIO/whatsapp-project.git
cd whatsapp-project
```

### Opção B: Via SCP (Mais rápido para teste)

**No seu computador:**

```bash
cd /Users/bestrizportella/Documents/desenvolvimentoWeb/WhatsApp-project

# Criar arquivo zip (excluindo node_modules)
zip -r whatsapp-project.zip . -x "node_modules/*" -x "auth_info/*" -x ".wwebjs_auth/*"

# Enviar para servidor
scp -i ~/.ssh/whatsapp-aws-key.pem whatsapp-project.zip ubuntu@SEU_IP_PUBLICO:~/

# Conectar ao servidor
ssh -i ~/.ssh/whatsapp-aws-key.pem ubuntu@SEU_IP_PUBLICO

# Descompactar
unzip whatsapp-project.zip -d whatsapp-project
cd whatsapp-project
```

---

## 5️⃣ CONFIGURAR PROJETO NO SERVIDOR

### Instalar Dependências

```bash
npm install
```

### Configurar Variáveis de Ambiente

```bash
nano .env
```

Cole (com suas credenciais do Supabase):

```env
DATABASE_URL=postgresql://postgres:SUA_SENHA@db.seu-projeto.supabase.co:5432/postgres
PORT=3000
NODE_ENV=production
```

Salvar: `Ctrl + O` → `Enter` → `Ctrl + X`

---

## 6️⃣ CONECTAR WHATSAPP (PRIMEIRA VEZ)

```bash
node src/bot-whatsapp-web.js
```

**Aguarde o QR Code aparecer!**

> ⚠️ **IMPORTANTE:** O QR Code NÃO vai aparecer visualmente no terminal SSH!

### Solução: Usar túnel SSH para ver o QR Code

**No seu computador (novo terminal):**

```bash
ssh -i ~/.ssh/whatsapp-aws-key.pem -L 3000:localhost:3000 ubuntu@SEU_IP_PUBLICO
```

Depois, no servidor, execute:

```bash
node src/bot-whatsapp-web.js
```

O QR Code vai aparecer no terminal! Escaneie com seu WhatsApp.

Quando aparecer "✅ WhatsApp conectado!", pressione `Ctrl + C`.

---

## 7️⃣ INICIAR COM PM2 (PRODUÇÃO)

```bash
# Iniciar ambos os processos
pm2 start ecosystem.config.js

# Configurar para iniciar automaticamente
pm2 startup
# Copie e execute o comando que aparecer

# Salvar configuração
pm2 save

# Ver status
pm2 status

# Ver logs
pm2 logs
```

---

## 8️⃣ ACESSAR INTERFACE

Abra o navegador em:

```
http://SEU_IP_PUBLICO:3000
```

---

## 9️⃣ CONFIGURAR DOMÍNIO (OPCIONAL)

Se você tem um domínio (ex: atendimento.seusite.com):

### Instalar Nginx

```bash
sudo apt install -y nginx
```

### Configurar Nginx

```bash
sudo nano /etc/nginx/sites-available/whatsapp
```

Cole:

```nginx
server {
    listen 80;
    server_name atendimento.seusite.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Ativar configuração
sudo ln -s /etc/nginx/sites-available/whatsapp /etc/nginx/sites-enabled/

# Testar
sudo nginx -t

# Reiniciar
sudo systemctl restart nginx
```

### Instalar SSL (HTTPS)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d atendimento.seusite.com
```

---

## 🔒 SEGURANÇA

### Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### Atualizar Regras EC2

No console AWS, edite o Security Group:
- **Remova** a regra da porta 3000 (se usar Nginx)
- **Mantenha** apenas SSH, HTTP e HTTPS

---

## 📊 MANUTENÇÃO

### Ver Logs

```bash
pm2 logs
```

### Reiniciar

```bash
pm2 restart all
```

### Atualizar Código

```bash
cd ~/whatsapp-project
git pull  # Se usar Git
pm2 restart all
```

### Backup da Sessão WhatsApp

```bash
# Fazer backup
tar -czf whatsapp-session-backup.tar.gz auth_info/

# Baixar para seu computador
scp -i ~/.ssh/whatsapp-aws-key.pem ubuntu@SEU_IP_PUBLICO:~/whatsapp-session-backup.tar.gz ~/Downloads/
```

---

## ⚠️ IMPORTANTE

### Custos AWS

- **Free Tier:** 750 horas/mês de t2.micro (suficiente para 1 servidor 24/7)
- **Válido por:** 12 meses
- **Depois:** ~$8-10/mês

### Monitorar Uso

1. AWS Console → Billing Dashboard
2. Configure alertas de custo

---

## ✅ CHECKLIST DE DEPLOY

- [ ] Instância EC2 criada (t2.micro)
- [ ] Conectado via SSH
- [ ] Node.js 20 instalado
- [ ] PM2 instalado
- [ ] Dependências do Chromium instaladas
- [ ] Projeto enviado para servidor
- [ ] npm install executado
- [ ] .env configurado
- [ ] QR Code escaneado
- [ ] PM2 iniciado
- [ ] PM2 configurado para auto-start
- [ ] Interface acessível via IP público
- [ ] (Opcional) Domínio configurado
- [ ] (Opcional) SSL instalado

---

**Sistema rodando 24/7 na AWS! 🎉**
