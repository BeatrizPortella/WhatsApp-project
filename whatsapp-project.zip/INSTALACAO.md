# 🚀 Guia Rápido de Instalação

## Passo a Passo para Executar Localmente

### 1️⃣ Instalar Dependências

```bash
cd /Users/bestrizportella/Documents/desenvolvimentoWeb/WhatsApp-project
npm install
```

### 2️⃣ Configurar Supabase

1. Acesse: https://supabase.com
2. Crie uma conta gratuita
3. Clique em "New Project"
4. Preencha:
   - Nome: `whatsapp-atendimento`
   - Database Password: (crie uma senha forte e anote!)
   - Região: South America (São Paulo)
5. Aguarde 2 minutos para o projeto ser criado

### 3️⃣ Criar Tabelas no Banco

1. No Supabase, vá em **SQL Editor** (menu lateral)
2. Clique em "New Query"
3. Abra o arquivo `database/schema.sql` deste projeto
4. Copie TODO o conteúdo
5. Cole no SQL Editor do Supabase
6. Clique em **Run** (ou pressione Ctrl+Enter)
7. Aguarde mensagem de sucesso

### 4️⃣ Copiar Connection String

1. No Supabase, vá em **Settings** > **Database**
2. Role até "Connection String"
3. Selecione a aba **URI**
4. Clique em "Copy" para copiar a string
5. **Importante:** Substitua `[YOUR-PASSWORD]` pela senha que você criou no passo 2

### 5️⃣ Criar Arquivo .env

```bash
cp .env.example .env
nano .env
```

Cole a Connection String (já com a senha substituída):

```env
DATABASE_URL=postgresql://postgres:SUA_SENHA_AQUI@db.seu-projeto.supabase.co:5432/postgres
PORT=3000
NODE_ENV=development
```

Salve: `Ctrl + O` → `Enter` → `Ctrl + X`

### 6️⃣ Primeira Execução (Gerar QR Code)

```bash
node src/bot.js
```

**O que vai acontecer:**
1. Aparecerá um QR Code no terminal
2. Abra o WhatsApp no celular
3. Vá em: **Aparelhos conectados** → **Conectar aparelho**
4. Escaneie o QR Code
5. Aguarde a mensagem: `✅ WhatsApp conectado com sucesso!`
6. Pressione `Ctrl + C` para parar

### 7️⃣ Testar o Sistema Completo

Abra **2 terminais** separados:

**Terminal 1 - Bot:**
```bash
node src/bot.js
```

**Terminal 2 - Servidor Web:**
```bash
node src/server.js
```

### 8️⃣ Acessar Interface

Abra o navegador em: **http://localhost:3000**

### 9️⃣ Testar Envio/Recebimento

1. Envie uma mensagem para o número conectado (de outro celular)
2. A mensagem deve aparecer na interface web
3. Selecione um atendente (João ou Maria)
4. Digite uma resposta e clique em "Enviar"
5. A mensagem deve chegar no WhatsApp com o prefixo do atendente

---

## ✅ Tudo Funcionando? Use PM2 para Produção

### Instalar PM2 Globalmente

```bash
npm install -g pm2
```

### Iniciar com PM2

```bash
npm run pm2:start
```

### Verificar Status

```bash
pm2 status
```

### Ver Logs

```bash
pm2 logs
```

### Parar Tudo

```bash
pm2 stop all
```

---

## 🆘 Problemas Comuns

### QR Code não aparece
```bash
rm -rf auth_info
node src/bot.js
```

### Erro de conexão com banco
- Verifique se a `DATABASE_URL` está correta no `.env`
- Verifique se executou o `schema.sql` no Supabase
- Teste a conexão no Supabase Dashboard

### Porta 3000 já em uso
```bash
lsof -i :3000
kill -9 <PID>
```

Ou mude a porta no `.env`:
```env
PORT=3001
```

---

**Pronto! Sistema funcionando! 🎉**
