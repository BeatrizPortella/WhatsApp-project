require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const {
    listarConversas,
    listarMensagens,
    listarAtendentes,
    obterAtendente,
    salvarMensagemAtendente,
    atualizarStatusConversa
} = require('./database');
const { enviarMensagem, connectToWhatsApp } = require('./bot-whatsapp-web');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// IMPORTANTE: NÃO inicia o bot aqui!
// O bot deve ser iniciado separadamente com: node src/bot-whatsapp-web.js
// connectToWhatsApp(); // ← COMENTADO para evitar conflito

// ==================== ROTAS DA API ====================

/**
 * GET /api/conversas
 * Lista todas as conversas
 */
app.get('/api/conversas', async (req, res) => {
    try {
        const conversas = await listarConversas();
        res.json({ success: true, data: conversas });
    } catch (error) {
        console.error('Erro ao listar conversas:', error);
        res.status(500).json({ success: false, error: 'Erro ao listar conversas' });
    }
});

/**
 * GET /api/mensagens/:conversaId
 * Lista mensagens de uma conversa específica
 */
app.get('/api/mensagens/:conversaId', async (req, res) => {
    try {
        const { conversaId } = req.params;
        const mensagens = await listarMensagens(conversaId);
        res.json({ success: true, data: mensagens });
    } catch (error) {
        console.error('Erro ao listar mensagens:', error);
        res.status(500).json({ success: false, error: 'Erro ao listar mensagens' });
    }
});

/**
 * GET /api/atendentes
 * Lista todos os atendentes ativos
 */
app.get('/api/atendentes', async (req, res) => {
    try {
        const atendentes = await listarAtendentes();
        res.json({ success: true, data: atendentes });
    } catch (error) {
        console.error('Erro ao listar atendentes:', error);
        res.status(500).json({ success: false, error: 'Erro ao listar atendentes' });
    }
});

/**
 * POST /api/enviar
 * Envia mensagem para um cliente
 * Body: { numero, texto, atendenteId }
 */
app.post('/api/enviar', async (req, res) => {
    try {
        const { numero, texto, atendenteId } = req.body;

        // Validações
        if (!numero || !texto || !atendenteId) {
            return res.status(400).json({
                success: false,
                error: 'Parâmetros obrigatórios: numero, texto, atendenteId'
            });
        }

        // Obtém informações do atendente
        const atendente = await obterAtendente(atendenteId);
        if (!atendente) {
            return res.status(404).json({
                success: false,
                error: 'Atendente não encontrado'
            });
        }

        // Envia mensagem via WhatsApp
        await enviarMensagem(numero, texto, atendenteId, atendente.nome);

        // Salva no banco de dados
        await salvarMensagemAtendente(numero, atendenteId, texto);

        res.json({
            success: true,
            message: 'Mensagem enviada com sucesso',
            atendente: atendente.nome
        });

    } catch (error) {
        console.error('Erro ao enviar mensagem:', error);
        res.status(500).json({
            success: false,
            error: 'Erro ao enviar mensagem: ' + error.message
        });
    }
});

/**
 * PUT /api/conversa/:conversaId/status
 * Atualiza status de uma conversa
 * Body: { status }
 */
app.put('/api/conversa/:conversaId/status', async (req, res) => {
    try {
        const { conversaId } = req.params;
        const { status } = req.body;

        // Validação
        const statusValidos = ['aguardando', 'em_atendimento', 'finalizado'];
        if (!statusValidos.includes(status)) {
            return res.status(400).json({
                success: false,
                error: 'Status inválido. Use: aguardando, em_atendimento ou finalizado'
            });
        }

        await atualizarStatusConversa(conversaId, status);

        res.json({
            success: true,
            message: 'Status atualizado com sucesso'
        });

    } catch (error) {
        console.error('Erro ao atualizar status:', error);
        res.status(500).json({
            success: false,
            error: 'Erro ao atualizar status'
        });
    }
});

/**
 * GET /api/status
 * Verifica status do servidor e conexão WhatsApp
 */
app.get('/api/status', (req, res) => {
    res.json({
        success: true,
        servidor: 'online',
        timestamp: new Date().toISOString()
    });
});

// Rota padrão - serve a interface web
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Tratamento de erros 404
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Rota não encontrada'
    });
});

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`\n🌐 Servidor rodando em http://localhost:${PORT}`);
    console.log(`📱 Interface de atendimento: http://localhost:${PORT}\n`);
});

// Tratamento de erros não capturados
process.on('unhandledRejection', (error) => {
    console.error('❌ Erro não tratado:', error);
});

module.exports = app;
