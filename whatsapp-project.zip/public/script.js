// Estado global da aplicação
let conversaAtual = null;
let atendentes = [];
let intervalAtualizacao = null;

// Inicializa a aplicação
document.addEventListener('DOMContentLoaded', () => {
    carregarAtendentes();
    carregarConversas();
    iniciarAtualizacaoAutomatica();
});

/**
 * Carrega lista de atendentes
 */
async function carregarAtendentes() {
    try {
        const response = await fetch('/api/atendentes');
        const result = await response.json();

        if (result.success) {
            atendentes = result.data;
            preencherSelectAtendentes();
        }
    } catch (error) {
        console.error('Erro ao carregar atendentes:', error);
    }
}

/**
 * Preenche o select de atendentes
 */
function preencherSelectAtendentes() {
    const select = document.getElementById('atendente-select');
    select.innerHTML = '<option value="">Selecione o atendente</option>';

    atendentes.forEach(atendente => {
        const option = document.createElement('option');
        option.value = atendente.id;
        option.textContent = atendente.nome;
        select.appendChild(option);
    });
}

/**
 * Carrega lista de conversas
 */
async function carregarConversas() {
    try {
        const response = await fetch('/api/conversas');
        const result = await response.json();

        if (result.success) {
            renderizarConversas(result.data);
        }
    } catch (error) {
        console.error('Erro ao carregar conversas:', error);
        document.getElementById('conversas-lista').innerHTML =
            '<div class="loading">Erro ao carregar conversas</div>';
    }
}

/**
 * Renderiza lista de conversas na sidebar
 */
function renderizarConversas(conversas) {
    const container = document.getElementById('conversas-lista');

    if (conversas.length === 0) {
        container.innerHTML = '<div class="loading">Nenhuma conversa ainda</div>';
        return;
    }

    container.innerHTML = conversas.map(conversa => {
        const numero = formatarNumero(conversa.numero_cliente);
        const hora = formatarHora(conversa.ultima_mensagem_em || conversa.criado_em);
        const preview = conversa.ultima_mensagem || 'Sem mensagens';
        const naoLidas = parseInt(conversa.mensagens_nao_lidas) || 0;
        const ativa = conversaAtual?.id === conversa.id ? 'ativa' : '';

        return `
            <div class="conversa-item ${ativa}" onclick="abrirConversa(${conversa.id}, '${conversa.numero_cliente}', '${conversa.status}')">
                <div class="conversa-header">
                    <span class="conversa-numero">${numero}</span>
                    <span class="conversa-hora">${hora}</span>
                </div>
                <div class="conversa-preview">${preview}</div>
                <div class="conversa-footer">
                    ${conversa.atendente_nome ?
                `<span class="conversa-atendente">👤 ${conversa.atendente_nome}</span>` :
                '<span class="conversa-atendente">⏳ Aguardando</span>'
            }
                    ${naoLidas > 0 ?
                `<span class="badge-nao-lidas">${naoLidas}</span>` :
                ''
            }
                </div>
            </div>
        `;
    }).join('');
}

/**
 * Abre uma conversa específica
 */
async function abrirConversa(id, numero, status) {
    conversaAtual = { id, numero, status };

    // Atualiza UI
    document.getElementById('chat-vazio').style.display = 'none';
    document.getElementById('chat-ativo').style.display = 'flex';
    document.getElementById('chat-numero').textContent = formatarNumero(numero);
    document.getElementById('chat-status').textContent = traduzirStatus(status);
    document.getElementById('status-select').value = status;

    // Carrega mensagens
    await carregarMensagens(id);

    // Atualiza lista de conversas para marcar como ativa
    carregarConversas();
}

/**
 * Carrega mensagens de uma conversa
 */
async function carregarMensagens(conversaId) {
    try {
        const response = await fetch(`/api/mensagens/${conversaId}`);
        const result = await response.json();

        if (result.success) {
            renderizarMensagens(result.data);
        }
    } catch (error) {
        console.error('Erro ao carregar mensagens:', error);
        document.getElementById('mensagens-container').innerHTML =
            '<div class="loading">Erro ao carregar mensagens</div>';
    }
}

/**
 * Renderiza mensagens no chat
 */
function renderizarMensagens(mensagens) {
    const container = document.getElementById('mensagens-container');

    if (mensagens.length === 0) {
        container.innerHTML = '<div class="loading">Nenhuma mensagem ainda</div>';
        return;
    }

    container.innerHTML = mensagens.map(msg => {
        const hora = formatarHora(msg.enviado_em);
        const tipo = msg.remetente_tipo;

        let conteudo = msg.conteudo;

        // Se for mensagem de atendente, destaca o nome
        if (tipo === 'atendente' && msg.atendente_nome) {
            conteudo = `<span class="mensagem-atendente-nome">${msg.atendente_nome}:</span> ${conteudo}`;
        }

        return `
            <div class="mensagem ${tipo}">
                <div class="mensagem-conteudo">
                    <div class="mensagem-texto">${conteudo}</div>
                    <div class="mensagem-hora">${hora}</div>
                </div>
            </div>
        `;
    }).join('');

    // Scroll para o final
    container.scrollTop = container.scrollHeight;
}

/**
 * Envia mensagem
 */
async function enviarMensagem() {
    const input = document.getElementById('mensagem-input');
    const selectAtendente = document.getElementById('atendente-select');

    const texto = input.value.trim();
    const atendenteId = selectAtendente.value;

    // Validações
    if (!texto) {
        alert('Digite uma mensagem');
        return;
    }

    if (!atendenteId) {
        alert('Selecione um atendente');
        return;
    }

    if (!conversaAtual) {
        alert('Selecione uma conversa');
        return;
    }

    try {
        const response = await fetch('/api/enviar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                numero: conversaAtual.numero,
                texto: texto,
                atendenteId: parseInt(atendenteId)
            })
        });

        const result = await response.json();

        if (result.success) {
            // Limpa input
            input.value = '';

            // Recarrega mensagens
            await carregarMensagens(conversaAtual.id);

            // Atualiza lista de conversas
            carregarConversas();
        } else {
            alert('Erro ao enviar mensagem: ' + result.error);
        }

    } catch (error) {
        console.error('Erro ao enviar mensagem:', error);
        alert('Erro ao enviar mensagem. Verifique a conexão.');
    }
}

/**
 * Atualiza status da conversa
 */
async function atualizarStatus() {
    if (!conversaAtual) return;

    const select = document.getElementById('status-select');
    const novoStatus = select.value;

    try {
        const response = await fetch(`/api/conversa/${conversaAtual.id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: novoStatus })
        });

        const result = await response.json();

        if (result.success) {
            conversaAtual.status = novoStatus;
            document.getElementById('chat-status').textContent = traduzirStatus(novoStatus);
            carregarConversas();
        }

    } catch (error) {
        console.error('Erro ao atualizar status:', error);
    }
}

/**
 * Permite enviar mensagem com Enter
 */
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        enviarMensagem();
    }
}

/**
 * Inicia atualização automática das conversas
 */
function iniciarAtualizacaoAutomatica() {
    // Atualiza a cada 5 segundos
    intervalAtualizacao = setInterval(() => {
        carregarConversas();

        // Se há conversa aberta, atualiza mensagens
        if (conversaAtual) {
            carregarMensagens(conversaAtual.id);
        }
    }, 5000);
}

// ========== FUNÇÕES AUXILIARES ==========

/**
 * Formata número de telefone
 */
function formatarNumero(numero) {
    // Remove @s.whatsapp.net
    const limpo = numero.replace('@s.whatsapp.net', '');

    // Formata: +55 11 99999-9999
    if (limpo.length >= 12) {
        return `+${limpo.slice(0, 2)} ${limpo.slice(2, 4)} ${limpo.slice(4, 9)}-${limpo.slice(9)}`;
    }

    return limpo;
}

/**
 * Formata hora
 */
function formatarHora(dataISO) {
    if (!dataISO) return '';

    const data = new Date(dataISO);
    const agora = new Date();

    // Se for hoje, mostra só a hora
    if (data.toDateString() === agora.toDateString()) {
        return data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    // Se for ontem
    const ontem = new Date(agora);
    ontem.setDate(ontem.getDate() - 1);
    if (data.toDateString() === ontem.toDateString()) {
        return 'Ontem';
    }

    // Caso contrário, mostra a data
    return data.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

/**
 * Traduz status para português
 */
function traduzirStatus(status) {
    const traducoes = {
        'aguardando': 'Aguardando',
        'em_atendimento': 'Em Atendimento',
        'finalizado': 'Finalizado'
    };

    return traducoes[status] || status;
}
